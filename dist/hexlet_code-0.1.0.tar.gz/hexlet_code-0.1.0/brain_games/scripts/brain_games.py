#!/usr/bin/env python

def greet(who):
    print('{}'.format(who))

def main():
    greet('Welcome to the Brain Games!')
    
if __name__ == '__main__':
    main()

